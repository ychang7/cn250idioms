// 成语数据（包含拼音）- 完整250个
const idioms = [
    { id: 1, idiom: "爱屋及乌", pinyin: "ài wū jí wū", english: "To love and accept someone completely.", explanation: "因为爱一个人而连带爱他屋上的乌鸦。比喻爱一个人而连带地关心到与他有关的人或物。", example: "爸爸深爱妈妈，因此把妈妈的亲友当作自己的亲友看待，真是爱屋及乌" },
    { id: 2, idiom: "按部就班", pinyin: "àn bù jiù bān", english: "Follow the proper procedures", explanation: "按照一定的步骤和次序。也指按老规矩办事，缺乏创新精神。", example: "我们办事应该按部就班，不可以总想着一步登天，急于求成。" },
    { id: 3, idiom: "百年树人", pinyin: "bǎi nián shù rén", english: "Refers to education as a life-long process", explanation: "树：培植，培养。比喻培养人才是长久之计。也表示培养人才很不容易。", example: "正所谓"十年树木，百年树人"，我们应该从长远考虑，把培养人才这件大事抓好。" },
    { id: 4, idiom: "百折不挠", pinyin: "bǎi zhé bù náo", english: "Be undaunted by repeated setbacks; Keep on fighting in spite of all setbacks.", explanation: "折:挫折,挠:弯曲.比喻意志坚强.无论受到多少次挫折.毫不动摇退缩.", example: "爱迪生在多次实验失败的情况下，百折不挠，愈挫愈勇，终于找到了合适的灯丝材料。" },
    { id: 5, idiom: "班门弄斧", pinyin: "bān mén nòng fǔ", english: "To show off one's talent or skill before an expert.", explanation: "班：鲁班，古代巧匠。在鲁班门前耍弄斧头。比喻在行家面前卖弄本领。也可以用来表示谦虚。", example: "在座的都是国内鼎鼎大名的作家，让我在这个写作研讨会上发言真的是班门弄斧。" },
    { id: 6, idiom: "半途而废", pinyin: "bàn tú ér fèi", english: "Give up halfway; Leave something unfinished.", explanation: "废：停止。 指做事不能坚持到底，中途停顿，有始无终。", example: "无论做什么事，都应持之以恒，有始有终，若半途而废，永远不会成功。" },
    { id: 7, idiom: "杯弓蛇影", pinyin: "bēi gōng shé yǐng", english: "Extremely suspicious", explanation: "将映在酒杯里的弓影误认为蛇.比喻因疑神疑鬼而引起恐惧.", example: "看清楚!那只是块石头，不是炸弹!别杯弓蛇影自己吓自己" },
    { id: 8, idiom: "杯水车薪", pinyin: "bēi shuǐ chē xīn", english: "An utterly inadequate measure.", explanation: "用一杯水去救一车着了火的柴草。比喻力量太小，解决不了问题。", example: "他那微薄的工资对于全家庞大的开销简直是杯水车薪啊!" },
    { id: 9, idiom: "悲天悯人", pinyin: "bēi tiān mǐn rén", english: "Compassion for the world", explanation: "指对混乱的时世感到悲伤，对人们的痛苦表示怜悯.", example: "这位宗教家具有悲天悯人的胸怀，一心一意要解救世间的苦难。" },
    { id: 10, idiom: "闭门造车", pinyin: "bì mén zào chē", english: "Detach oneself from reality and do things without considering the actual conditions.", explanation: "关起门来造车子.比喻脱离实际,只凭主观办事.", example: "工作要联系实际，还要多与同事们交流，不能闭门造车。" },
    { id: 11, idiom: "兵不厌诈", pinyin: "bīng bù yàn zhà", english: "There can never be too much deception in war.", explanation: "厌：满足，诈：欺骗手段。用兵作战可以尽可能多用欺诈的战术迷惑对方，以获取胜利。", example: "兵不厌诈，诸葛亮摆空城计，就把强敌迷惑了。" },
    { id: 12, idiom: "不耻下问", pinyin: "bù chǐ xià wèn", english: "Not feel ashamed to ask and learn from one's subordinates.", explanation: "不以向地位比自己低、学识比自己差的人请教为耻。", example: "在学习上，我们要有不耻下问的精神。" },
    { id: 13, idiom: "不二法门", pinyin: "bù èr fǎ mén", english: "The one and only way.", explanation: "不二:指不是两极端,法门:佧行入道的门径.原为佛家语.意为直接入道.不可言传的法门.后比喻最好的或独一无二的方法.", example: "努力学习是获取好成绩的不二法门。" },
    { id: 14, idiom: "不可救药", pinyin: "bù kě jiù yào", english: "Incurable; Hopeless.", explanation: "药：用药治疗。病已重到无法用药医治的程度。比喻已经到了无法挽救的地步。", example: "张大叔嗜赌如命，已经到了不可救药的地步了。" },
    { id: 15, idiom: "不劳而获", pinyin: "bù láo ér huò", english: "Gain or profit without working for it.", explanation: "自己不劳动而得到别人的劳动成果。", example: "世上没有不劳而获的事，努力工作才能过上幸福的生活。" },
    { id: 16, idiom: "不胜枚举", pinyin: "bù shèng méi jǔ", english: "Too numerous to mention individually.", explanation: "胜:尽;枚:个.不能一个个地列举出来.形容数量很多.", example: "最近几年，游客投诉购物受骗的事件不胜枚举，警方已开始向有关商店采取行动。" },
    { id: 17, idiom: "不务正业", pinyin: "bù wù zhèng yè", english: "Not engage in a proper job; Has not concern for one's responsibilities.", explanation: "不做正当的事，也指放下本身的工作而去做别的事情。", example: "这些青年不务正业，你还是少跟他们来往，以免惹祸。" },
    { id: 18, idiom: "不翼而飞", pinyin: "bù yì ér fēi", english: "Disappear without trace; Vanish all of a sudden", explanation: "翼：翅膀。没有翅膀却飞走了。比喻物品忽然丢失。也比喻事情传播得很迅速。", example: "我的钱明明昨天放在这里,现在却不翼而飞了" },
    { id: 19, idiom: "不知所措", pinyin: "bù zhī suǒ cuò", english: "Be at a loss.", explanation: "不知怎么办才好。", example: "她被地震吓呆了，一时不知所措。" },
    { id: 20, idiom: "不自量力", pinyin: "bù zì liàng lì", english: "Overestimate one's own abilities.", explanation: "量：估量。自己不估量自己的能力。指过高地估计自己的实力。", example: "你才懂得一点皮毛功夫就向武术大师挑战,未免太不自量力了吧!" },
    { id: 21, idiom: "沧海桑田", pinyin: "cāng hǎi sāng tián", english: "Time brings great changes to the world.", explanation: "沧海:大海,桑田:种桑树的地 泛指农田.大海变成农田，农田变成大海 比喻世事变化很大", example: "几十年过去了，沧海桑田,新加坡已发生了翻天覆地的变化" },
    { id: 22, idiom: "长年累月", pinyin: "cháng nián lěi yuè", english: "For months and years.", explanation: "长年:整年,累月:很多个月.形容经过了很长的时间.", example: "他长年累月地辛苦工作，最后病倒了。" },
    { id: 23, idiom: "长袖善舞", pinyin: "cháng xiù shàn wǔ", english: "In praise of capable businessmen.", explanation: "袖子长，有利于起舞.原指有所依靠，事情就容易成功.后形容有财势会耍手腕的人，善于钻营取巧。", example: "王老板生意做得很成功，是因为他长袖善舞，结识了许多政府高官，" },
    { id: 24, idiom: "草木皆兵", pinyin: "cǎo mù jiē bīng", english: "A state of extreme nervousness.", explanation: "把山上的草木都当做敌兵.形容人在惊慌时疑神疑鬼", example: ""911事件"发生后，美国民众闻恐色变,已然风声鹤唳,草木皆兵。" },
    { id: 25, idiom: "城门失火,殃及池鱼", pinyin: "chéng mén shī huǒ, yāng jí chí yú", english: "In a disturbance innocent by standers get into trouble.", explanation: "城门失火,大家都到护城河取水,水用完了,鱼也死了.比喻因受连累而遭到损失或祸害.", example: "他的投资失败连累家人受到损失，真是城门失火，殃及池鱼。" },
    { id: 26, idiom: "痴人说梦", pinyin: "chī rén shuō mèng", english: "Idiotic nonsense.", explanation: "原指对着痴人说假话，而痴人信以为真。后用以讽刺说无根据的荒唐话的人。", example: "他每天什么都不做,却总对人说自己将来会成为亿万富豪，无异于痴人说梦" },
    { id: 27, idiom: "持之以恒", pinyin: "chí zhī yǐ héng", english: "Persevere", explanation: "持:坚持,恒:恒心 长久坚持下去。", example: "学习要勤奋,持之以恒,这样才能获得好成绩。" },
    { id: 28, idiom: "出尔反尔", pinyin: "chū ěr fǎn ěr", english: "To contradict oneself", explanation: "指说出口的是你，反悔的也是你.现多指言而无信, 言行前后自相矛盾", example: "合同已经签定了，请双方遵守约定，不要出尔反尔。" },
    { id: 29, idiom: "出类拔萃", pinyin: "chū lèi bá cuì", english: "To excel; surpass the common", explanation: "超出同类之上.多指人的品德才能高出一般人。", example: "在电脑研究方面，刘博士是个出类拔萃的专家。" },
    { id: 30, idiom: "出人头地", pinyin: "chū rén tóu dì", english: "to stand out among peers", explanation: "超出别人之上或高人一等。", example: "小王整日刻苦学习，希望自己将来能出人头地。" },
    { id: 31, idiom: "吹毛求疵", pinyin: "chuī máo qiú cī", english: "to look for flaws in someone; nitpick", explanation: "求：寻找；疵：缺点，小毛病。吹开皮上的毛，寻找里面的毛病。比喻故意挑剔别人的毛病、缺点，寻找差错", example: "小明是个挑剔的孩子，凡事喜欢吹毛求疵。" },
    { id: 32, idiom: "垂涎三尺", pinyin: "chuí xián sān chǐ", english: "to yearn for; drool", explanation: "口水挂下三尺长。形容极其贪婪的样子。也形容非常眼热。", example: "面对着满桌的美味佳肴，我不禁垂涎三尺。" },
    { id: 33, idiom: "唇亡齿寒", pinyin: "chún wáng chǐ hán", english: "If one fails, other will be in danger; closely linked", explanation: "嘴唇没有了，牙齿就会感到寒冷。比喻利害密要相关。", example: "这两家公司有着多种业务关系，正所谓是唇亡齿寒。" },
    { id: 34, idiom: "粗制滥造", pinyin: "cū zhì làn zào", english: "sloppy work", explanation: "滥：过多，不加节制。写文章或做东西马虎草率，只求数量，不顾质量。", example: "这部影片除了特技效果以外，完全是一部粗制滥造的电影。" },
    { id: 35, idiom: "打草惊蛇", pinyin: "dǎ cǎo jīng shé", english: "act rashly and alert enemy", explanation: "原比喻惩甲菟乙。后多比喻做法不谨慎，反使对方有所戒备。", example: "为避免打草惊蛇，我们先派人到敌营探访军情，然后再商讨对策。" },
    { id: 36, idiom: "大公无私", pinyin: "dà gōng wú sī", english: "selfless", explanation: "指办事公正，没有私心。现多指从集体利益出发，毫无个人打算。", example: "其实，生活当中还是有一些舍己为人，大公无私的人，为了别人而毫不犹豫地牺牲自己。" },
    { id: 37, idiom: "大言不惭", pinyin: "dà yán bù cán", english: "brag unblushingly", explanation: "说大话，不感到难为情。", example: "英文很差的小钟大言不惭地说自己的英文歌绝对能唱赢外国歌星。" },
    { id: 38, idiom: "当机立断", pinyin: "dāng jī lì duàn", english: "make a prompt decision", explanation: "当机：抓住时机。在紧要时刻立即做出决断。", example: "村长见风雨交加，水位上升，当机立断，要村民赶快撤离。" },
    { id: 39, idiom: "当仁不让", pinyin: "dāng rén bù ràng", english: "unwilling to pass on responsibility to others", explanation: "原指以仁为任，无所谦让。后指遇到应该做的事就积极主动去做，不推让", example: "只要是正当的事，我们都应该当仁不让。" },
    { id: 40, idiom: "德高望重", pinyin: "dé gāo wàng zhòng", english: "a person of high moral standing and reputation", explanation: "德：品德；望：声望。道德高尚，名望很大。", example: "刘教授对学术界贡献良多，极受国际推崇，是位德高望重的学者。" },
    { id: 41, idiom: "得过且过", pinyin: "dé guò qiě guò", english: "get by however on can", explanation: "且：暂且。只要能够过得去，就这样过下去。形容胸无大志。", example: "要提高执行力，就必须树立起强烈的责任意识和进取精神，坚决克服不思进取、得过且过的心态。" },
    { id: 42, idiom: "得意忘形", pinyin: "dé yì wàng xíng", english: "be carried away with one's success", explanation: "形：形态。形容高兴得失去了常态。", example: "只是稍稍占上风，他便得意忘形，结果搞得自己满盘皆输。" },
    { id: 43, idiom: "雕虫小技", pinyin: "diāo chóng xiǎo jì", english: "insignificant skill(especially in writing)", explanation: "雕：雕刻；虫：指鸟虫书，古代汉字的一种字体。比喻小技或微不足道的技能。", example: "我这只是雕虫小技罢了，怎么能跟你们接受过专业训练的人比呢？" },
    { id: 44, idiom: "掉以轻心", pinyin: "diào yǐ qīng xīn", english: "lower one's guard", explanation: "掉：摆动；轻：轻率。对事情采取轻率的漫不经心的态度。", example: "对于小孩发热，父母虽然不必大惊小怪，却也不能掉以轻心，以免病情不可收拾。" },
    { id: 45, idiom: "东窗事发", pinyin: "dōng chuāng shì fā", english: "plot/secret is revealed", explanation: "比喻阴谋已败露。", example: "你干了那么多违背良心的事，一旦东窗事发，你应该知道会有什么下场。" },
    { id: 46, idiom: "东山再起", pinyin: "dōng shān zài qǐ", english: "to make a comeback", explanation: "指再度出任要职。也比喻失势之后又重新得势。", example: "失败不过是一时的挫折而已，只要能够好好从中汲取教训，就一定可以东山再起。" },
    { id: 47, idiom: "独善其身", pinyin: "dú shàn qí shēn", english: "only think of one's interest and not others", explanation: "独：唯独；善：好，维护。原意是做不上官就修养好自身。现指只顾自己，不管别人。", example: "国难当头 任何人都不可能独善其身 不理会身边的人和事。" },
    { id: 48, idiom: "对牛弹琴", pinyin: "duì niú tán qín", english: "address the wrong audience", explanation: "讥笑听话的人不懂对方说得是什么。用以讥笑说话的人不看对象。", example: "跟三岁的小孩讲这么深奥的大道理，简直就是对牛弹琴。" },
    { id: 49, idiom: "对症下药", pinyin: "duì zhèng xià yào", english: "take appropriate measures", explanation: "症：病症；下药：用药。针对病症用药。比喻针对具体问题，采取有效的措施", example: "凡事都有原因，要先找出问题的关键，然后对症下药，问题自然迎刃而解。" },
    { id: 50, idiom: "多多益善", pinyin: "duō duō yì shàn", english: "the more, the merrier", explanation: "益：更加。越多越好。", example: "现在的人都只关心自己，凡是对自己有利的事，总是尽力争取，多多益善。" },
    { id: 51, idiom: "耳濡目染", pinyin: "ěr rú mù rǎn", english: "influenced by others", explanation: "濡：沾湿；染：沾染。耳朵经常听到，眼睛经常看到，不知不觉地受到影响。", example: "他出身绘画之家，耳濡目染，对画画产生浓厚的兴趣。" },
    { id: 52, idiom: "发人深省", pinyin: "fā rén shēn xǐng", english: "thought-provoking", explanation: "发：启发；省：醒悟。启发人深刻思考，有所醒悟。", example: "这部影片寓意深刻，发人深省。" },
    { id: 53, idiom: "发扬光大", pinyin: "fā yáng guāng dà", english: "enhance/carry-forward", explanation: "发扬：发展，提倡；光大：辉煌而盛大。使好的作风、传统等得到发展和提高。", example: "华族的优良传统不但应该保存，还要加以发扬光大。" },
    { id: 54, idiom: "防患未然", pinyin: "fáng huàn wèi rán", english: "take preventive measures", explanation: "患：灾祸；未然：尚未形成。防止事故或祸害于尚未发生之前。", example: "山林中严禁烟火，我们必须防患未然，以免发生火患。" },
    { id: 55, idiom: "废寝忘食", pinyin: "fèi qǐn wàng shí", english: "forget to eat and sleep because too concentrated on something", explanation: "废：停止。顾不得睡觉，忘记了吃饭。形容专心努力。", example: "这几天他废寝忘食，日夜为参加朗读比赛作准备。" },
    { id: 56, idiom: "分庭抗礼", pinyin: "fēn tíng kàng lǐ", english: "stand up to somebody as an equal", explanation: "抗礼：平等行礼。原指宾主相见，分站在庭的两边，相对行礼。现比喻平起平坐，彼此对等的关系。", example: "老王和小李棋艺相当，赛场上他们各自代表自己的队伍，分庭抗礼，格外引人注目。" },
    { id: 57, idiom: "纷至沓来", pinyin: "fēn zhì tà lái", english: "come in a continuous stream", explanation: "纷：众多，杂乱；沓：多，重复。形容接连不断的到来。", example: "演唱会即将开始，观众纷至沓来，鱼贯进入会场。" },
    { id: 58, idiom: "奉公守法", pinyin: "fèng gōng shǒu fǎ", english: "law abiding", explanation: "奉：奉行；公：公务。奉公行事，遵守法令.。形容办事守规矩。", example: "林阿姨向来奉公守法，绝对不会做犯法的事情。" },
    { id: 59, idiom: "敷衍塞责", pinyin: "fū yǎn sè zé", english: "perform one's duty without care/ anyhow", explanation: "塞责：搪塞责任。指工作不认真负责，表面应付了事。", example: "主管最不满意的就是员工们有敷衍塞责的工作态度。" },
    { id: 60, idiom: "赴汤蹈火", pinyin: "fù tāng dǎo huǒ", english: "defy all difficulties and dangers", explanation: "赴：走往；汤：热水；蹈：踩。沸水敢蹚，烈火敢踏。比喻不避艰险，奋勇向前。", example: "为了完成任务，赴汤蹈火我也在所不辞。" },
    { id: 61, idiom: "改过自新", pinyin: "gǎi guò zì xīn", english: "turn over a new leaf", explanation: "改正过失，重新做人。", example: "那名罪犯向法官求情，希望法官能网开一面，给他一个改过自新的机会。" },
    { id: 62, idiom: "改邪归正", pinyin: "gǎi xié guī zhèng", english: "give up evil and return to good", explanation: "不再走邪路做坏事，回到正路上来。", example: "尽管它已经改邪归正，但人们仍不信任他。" },
    { id: 63, idiom: "高瞻远瞩", pinyin: "gāo zhān yuǎn zhǔ", english: "see high and far", explanation: "瞻：向前或向上看；瞩：注视。登高远视。形容眼光远大。", example: "年轻人要高瞻远瞩，放眼世界，才能有一番作为。" },
    { id: 64, idiom: "高枕无忧", pinyin: "gāo zhěn wú yōu", english: "set one's mind at ease", explanation: "把枕头垫的高高地安心睡觉。形容无忧无虑。也比喻没有挂虑或不加警惕。", example: "经验丰富的林先生担任总经理，公司里的股东们可以高枕无忧了。" },
    { id: 65, idiom: "各有千秋", pinyin: "gè yǒu qiān qiū", english: "each have their own strengths.", explanation: "千秋：指流传久远的东西。比喻各有所长，各有特点。", example: "这两篇文章写得很好，描写手法各有千秋。" },
    { id: 66, idiom: "根深蒂固", pinyin: "gēn shēn dì gù", english: "deep-rooted; rooted", explanation: "蒂：花或瓜果跟枝茎相连的部分。比喻基础牢固，不容易动摇。常用来比喻旧的势力、习惯等。", example: "几千年來,迷信已经在人们心中根深蒂固了,要想破除,并非一朝一夕可做到的。" },
    { id: 67, idiom: "勾心斗角", pinyin: "gōu xīn dòu jiǎo", english: "Intrigue against each other", explanation: "比喻各用心机，明争暗斗，互相排挤。", example: "为了争名夺利，这个部门里的主管勾心斗角，互相排挤。" },
    { id: 68, idiom: "苟且偷安", pinyin: "gǒu qiě tōu ān", english: "be content with temporary ease and comfort", explanation: "苟且：敷衍过去；偷安：只求暂时得过且过。形容只求眼前的安宁，不顾将来，不求上进。", example: "这种苟且偷安的生活，毫无意义，有什么意思呢？" },
    { id: 69, idiom: "孤陋寡闻", pinyin: "gū lòu guǎ wén", english: "ignorant and ill-informed", explanation: "陋：浅陋；寡：少。形容学识浅薄，见闻不广。", example: "他久居乡下，孤陋寡闻，外界许多事都一无所知。" },
    { id: 70, idiom: "沽名钓誉", pinyin: "gū míng diào yù", english: "fish for fame or compliments", explanation: "沽：买；钓：骗取。指用不正当的手段骗取名誉。", example: "他原本不学无术，为了沽名钓誉，便捐钱给这个协会，以获得名誉主席的头衔。" },
    { id: 71, idiom: "孤掌难鸣", pinyin: "gū zhǎng nán míng", english: "hard to succeed without support", explanation: "一个巴掌拍不响。比喻力量孤单，难以成事。", example: "我想做生意，但孤掌难鸣，若你肯合伙，那就再好不过了。" },
    { id: 72, idiom: "孤注一掷", pinyin: "gū zhù yī zhì", english: "risk everything in one attempt", explanation: "比喻在危急时，用尽所有力量做最后一次冒险。（多含贬义", example: "老王反对我这种孤注一掷的做法，认为这样太冒险了。" },
    { id: 73, idiom: "寡不敌众", pinyin: "guǎ bù dí zhòng", english: "fight against hopeless odds", explanation: "寡：少；敌：抵挡；众：多。人少的抵挡不住人多的。", example: "敌军知道他们寡不敌众，只好向我军投降。" },
    { id: 74, idiom: "管中窥豹", pinyin: "guǎn zhōng kuī bào", english: "have a limited view", explanation: "比喻只见到事物的一小部分。有时同"可见一斑"连用，比喻从观察到的部分，可以推测全貌。", example: "虽然我们在这里停留的时间不久，认识不深，但管中窥豹，还是可以观察到一些他们生活的精彩。" },
    { id: 75, idiom: "光明正大", pinyin: "guāng míng zhèng dà", english: "just and honorable", explanation: "原指明白不偏邪。现多指心怀坦白，言行正派。", example: "他做事一向光明正大，从不做偷偷摸摸的事。" },
    { id: 76, idiom: "海底捞针", pinyin: "hǎi dǐ lāo zhēn", english: "needle in a haystack; difficult to find", explanation: "在大海里捞一根针。形容很难找到。", example: "想在人潮中寻找遗失的戒指，就像海底捞针那么难。" },
    { id: 77, idiom: "海誓山盟", pinyin: "hǎi shì shān méng", english: "a solemn pledge of love", explanation: "指山海为誓言，表示爱情要像山海那样坚定不移。", example: "明强和慧敏立下海誓山盟，决定一起终老终生" },
    { id: 78, idiom: "害群之马", pinyin: "hài qún zhī mǎ", english: "one who brings disgrace to the group", explanation: "危害马群的劣马。比喻危害社会或集体的人。", example: "团队中若出现害群之马，必然会危害到整个团体的利益。" },
    { id: 79, idiom: "含沙射影", pinyin: "hán shā shè yǐng", english: "hurt others", explanation: "传说水中有一种怪物，看到人的影子就喷沙子，被喷着的人就会得病。比喻暗地里中伤，陷害别人", example: "她在公司总是爱含沙射影，中伤别人，导致公司员工之间不团结" },
    { id: 80, idiom: "汗牛充栋", pinyin: "hàn niú chōng dòng", english: "immense collection of books", explanation: "汗牛：使牛出汗。栋：屋子。用牛运书，牛要累得出汗；用屋子放书，要放满整个屋子。形容藏书很丰富。", example: "江先生家里的藏书虽然说不上汗牛充栋，但也有上万本了。" },
    { id: 81, idiom: "好逸恶劳", pinyin: "hào yì wù láo", english: "love ease, hate work", explanation: "逸：安逸；恶：讨厌、憎恨。贪图安逸，厌恶劳动。", example: "我们自己能做的事要尽量自己做，别养成好逸恶劳的坏习惯。" },
    { id: 82, idiom: "狐假虎威", pinyin: "hú jiǎ hǔ wēi", english: "bully people by flaunting one's powerful connections", explanation: "假：借。狐狸假借老虎的威势。比喻依仗别人的势力欺压人。", example: "他经常仗着经理对他的宠信，狐假虎威，欺负同事。" },
    { id: 83, idiom: "胡作非为", pinyin: "hú zuò fēi wéi", english: "act wildly in defiance of law", explanation: "胡：乱；非：不对。不顾法纪或舆论，毫无顾忌地做坏事。", example: "林太太从不管束孩子的行为，任由他们到处胡作非为。" },
    { id: 84, idiom: "花言巧语", pinyin: "huā yán qiǎo yǔ", english: "words of flattery", explanation: "原指铺张修饰、内容空泛的言语或文辞。后多指用来骗人的虚伪动听的话。", example: "他是个爱情骗子，专用花言巧语来骗女孩子的感情。" },
    { id: 85, idiom: "画龙点睛", pinyin: "huà lóng diǎn jīng", english: "add finishing touch", explanation: "比喻说话或写作文时，在关键部分用一两句话点明要旨，使全篇精警传神。", example: "在这篇文章里，老师只加了几句话文章立刻生色不少，真有画龙点睛之妙。" },
    { id: 86, idiom: "画蛇添足", pinyin: "huà shé tiān zú", english: "ruin something by adding extra details", explanation: "画蛇时给蛇添上脚。比喻做了多余的事，非但无益，反而不合适。也比喻虚构事实，无中生有。", example: "话已说得十分得体了，你还要再加上两句，不是画蛇添足吗？" },
    { id: 87, idiom: "诲人不倦", pinyin: "huì rén bù juàn", english: "teach tirelessly", explanation: "诲：教导。教导人特别耐心，从不厌倦。", example: "我敬爱我的老师，因为他有诲人不倦的精神。" },
    { id: 88, idiom: "混水摸鱼", pinyin: "hùn shuǐ mō yú", english: "create confusion to gain advantage", explanation: "混水：浊水。比喻趁紊乱局面或制造混乱以攫取不正当的利益。", example: "地震发生后，竟然有人想乘着纷乱混水摸鱼，抢夺灾民仅存的财物。" },
    { id: 89, idiom: "疾风知劲草", pinyin: "jí fēng zhī jìng cǎo", english: "strength of a character is tested in crisis", explanation: "比喻立场的坚定不移，即使遇到大难也决不变节。", example: "正所谓疾风知劲草，虽然林谋盛烈士被日军百般折磨，但他坚贞不屈令人十分敬佩。" },
    { id: 90, idiom: "家喻户晓", pinyin: "jiā yù hù xiǎo", english: "widely known", explanation: "喻：明白；晓：知道。家家户户都知道。形容人所共知。", example: "《西游记》是一部家喻户晓的章回小说，很多人都对小说中的人物十分熟悉。" },
    { id: 91, idiom: "假公济私", pinyin: "jiǎ gōng jì sī", english: "use public office for personal gain", explanation: "假：借；济：帮助。假借公家的名义，谋取私人的利益。", example: "有些人公车私用，分明就是假公济私" },
    { id: 92, idiom: "见仁见智", pinyin: "jiàn rén jiàn zhì", english: "people have different views or opinions", explanation: "对同一个问题，各人有各人的看法和道理。", example: "对这个问题，回答者由于立场不同，观点也是见仁见智。" },
    { id: 93, idiom: "见义勇为", pinyin: "jiàn yì yǒng wéi", english: "see something right then do it courageously", explanation: "看到正义的事，就勇敢地去做。", example: "要不是杰明见义勇为，冲进火场把我救出来，我早就被烧死了" },
    { id: 94, idiom: "捷足先登", pinyin: "jié zú xiān dēng", english: "faster one reach first", explanation: "行动快的人先达到目的。", example: "当我们到达藏宝的地方时，发现已经有人捷足先登，把宝藏搬走了。" },
    { id: 95, idiom: "解铃还需系铃人", pinyin: "jiě líng hái xū xì líng rén", english: "the one who causes the problem should fix", explanation: "比喻谁弄出来的事情，仍须由谁去解决。", example: "既然事情是你搞砸的，所谓解铃还需系铃人，我认为由你来处理最恰当" },
    { id: 96, idiom: "金科玉律", pinyin: "jīn kē yù lǜ", english: "golden rule", explanation: "比喻不可更改的信条。", example: "他是这个领域里的权威，他的话就是金科玉律。" },
    { id: 97, idiom: "金玉良言", pinyin: "jīn yù liáng yán", english: "golden advice from a wise person", explanation: "比喻非常宝贵的劝告或教诲。", example: "我们不要把老师的金玉良言当作耳边风。" },
    { id: 98, idiom: "近水楼台", pinyin: "jìn shuǐ lóu tái", english: "using one's proximity to one's favor.", explanation: "比喻由于地处近便而获得优先的机会。", example: "父亲有很多珍贵的藏书，我可以很方便地读这些书，可谓近水楼台。" },
    { id: 99, idiom: "进退维谷", pinyin: "jìn tuì wéi gǔ", english: "no way out", explanation: "谷：比喻困境。无论是进还是退，都是处在困境之中。形容进退两难。", example: "我们处于进退维谷的境地，不知该去还是该留。" },
    { id: 100, idiom: "近朱者赤，近墨者黑", pinyin: "jìn zhū zhě chì, jìn mò zhě hēi", english: "one's surroundings can influence someone", explanation: "靠近朱砂容易变成红色，靠近墨容易变黑。比喻客观环境对人的成长变化有很大的影响。", example: "正所谓"近朱者赤，近墨者黑"，我们在择友的时候要加倍小心，不要误交损友，受到不好的影响。" },
    // 继续添加剩余的150个成语...
    { id: 101, idiom: "惊弓之鸟", pinyin: "jīng gōng zhī niǎo", english: "someone who is easily frightened due to past experiences", explanation: "受过箭伤，闻弓弦声而惊堕的鸟。比喻受过惊吓遇有事情就害怕惊慌的人。", example: "经过上次惊吓，一有风吹草动，他就如惊弓之鸟，忙不迭的逃跑。" },
    { id: 102, idiom: "井井有条", pinyin: "jǐng jǐng yǒu tiáo", english: "everything clear and orderly", explanation: "井井：形容有条理。形容整齐不乱，有条有理。", example: "小张办事井井有条，很受老板的赏识。" },
    { id: 103, idiom: "咎由自取", pinyin: "jiù yóu zì qǔ", english: "blame oneself for problems caused", explanation: "咎：灾祸，罪过。罪过或灾祸是自己招来的、自己造成的。", example: "造成现在这种后果，完全是你咎由自取，怪不了别人！" },
    { id: 104, idiom: "居安思危", pinyin: "jū ān sī wēi", english: "think of dangers in times of safety", explanation: "处在安定的环境时而能想到可能会出现的危难。", example: "在和平时期，我们更要居安思危，增强忧患意识。" },
    { id: 105, idiom: "鞠躬尽瘁", pinyin: "jū gōng jìn cuì", english: "striving to the utmost", explanation: "表示小心谨慎，竭尽全力效劳。", example: "诸葛亮为蜀国鞠躬尽瘁,成就了一番丰功伟绩。" },
    { id: 106, idiom: "举足轻重", pinyin: "jǔ zú qīng zhòng", english: "every move of an important person has an impact", explanation: "只要脚移动一下，就会影响两边的轻重。形容处于重要地位，一举一动都足以影响全局。", example: "他是公司里举足轻重的人物,凡是重要的事情都由他决定。" },
    { id: 107, idiom: "开门见山", pinyin: "kāi mén jiàn shān", english: "get straight to the main point", explanation: "打开门就能看见山。比喻说话或写文章一开头就直截了当地进入正题。", example: "我们就开门见山地说吧，别绕来绕去了。" },
    { id: 108, idiom: "开源节流", pinyin: "kāi yuán jié liú", english: "increase income, reduce expenditure", explanation: "开：开辟。源：源头。节：节制。流：水流。比喻在财政上增加收入，节省开支。", example: "理财之道，无非就是开源节流。" },
    { id: 109, idiom: "慷慨解囊", pinyin: "kāng kǎi jiě náng", english: "give generously to charity", explanation: "慷慨：不吝惜。囊：口袋，指钱袋。指豪爽大方地在经济上帮助别人。", example: "看到灾区孩子们渴望读书的眼神，企业家们纷纷慷慨解囊。" },
    { id: 110, idiom: "口若悬河", pinyin: "kǒu ruò xuán hé", english: "talk non-stop", explanation: "若：好象。悬河：瀑布。形容人能言善辩，说起话来像瀑布倾泻一般滔滔不绝。", example: "这位演说家说起话来口若悬河，把大家的情绪都调动起来了。" },
    { id: 111, idiom: "口是心非", pinyin: "kǒu shì xīn fēi", english: "yes means no", explanation: "口里是一套，心里是另一套。形容心口不一。", example: "老张这个人一向心口不一，口是心非，别信他的。" },
    { id: 112, idiom: "苦口婆心", pinyin: "kǔ kǒu pó xīn", english: "admonish time and again with good", explanation: "形容好心好意，不辞烦劳地反复规劝。", example: "陈老师对我苦口婆心的劝导，我会永远记在心里。" },
    { id: 113, idiom: "苦心孤诣", pinyin: "kǔ xīn gū yì", english: "very hard until reached a higher level.", explanation: "苦心钻研，达到了别人所达不到的地步。也指为了达到目的而费尽心思。", example: "他在这个领域苦心孤诣钻研十年，颇有建树。" },
    { id: 114, idiom: "滥竽充数", pinyin: "làn yú chōng shù", english: "fill a post without any real qualifications", explanation: "滥：失实，不真实。比喻没有真实本领的人，混在行家队伍里充数。也比喻以次充好。", example: "南郭先生在皇宫乐队里滥竽充数，最后被识破，只好落荒而逃。" },
    { id: 115, idiom: "狼狈为奸", pinyin: "láng bèi wéi jiān", english: "act in cahoots wit each other", explanation: "比喻互相勾结，一起干坏事。", example: "贪官和奸商互相勾结，狼狈为奸，一起欺骗消费者。" },
    { id: 116, idiom: "老马识途", pinyin: "lǎo mǎ shí tú", english: "an experienced person knows the way", explanation: "老马认识路。比喻阅历多、经验丰富的人能看清方向，办事熟悉。", example: "有老马识途的老王领队,我们不会迷路。" },
    { id: 117, idiom: "礼尚往来", pinyin: "lǐ shàng wǎng lái", english: "courtesy demands reciprocity.", explanation: "尚：注重，重视。指礼节上重视互相往来。", example: "华人讲究礼尚往来，收到别人的礼物后，也会回赠一份礼物给人家。" },
    { id: 118, idiom: "理直气壮", pinyin: "lǐ zhí qì zhuàng", english: "with justice on one's side, one is bold and confident", explanation: "直：正确，充分。理由正确、充分，说话胆气壮。", example: "我们没有错，当然可以理直气壮地去责问他。" },
    { id: 119, idiom: "力不从心", pinyin: "lì bù cóng xīn", english: "unable to do as much as one would like to", explanation: "心里想做某事而力量办不到。", example: "我很想帮助你，可惜力不从心。" },
    { id: 120, idiom: "立竿见影", pinyin: "lì gān jiàn yǐng", english: "produce instant results", explanation: "在阳光下把竿子竖起来，立刻就看到影子。比喻立刻见到功效。", example: "这次训练的效果真是立竿见影，他取得了很大的进步。" },
    { id: 121, idiom: "励精图治", pinyin: "lì jīng tú zhì", english: "exert oneself to make country prosperous", explanation: "励：奋勉；图：设法；治：治理好国家。振奋精神，想办法治理好国家。", example: "康熙一生励精图治，开创了后人赞誉的"康乾盛世"。" },
    { id: 122, idiom: "良药苦口", pinyin: "liáng yào kǔ kǒu", english: "good medicine tastes bitter", explanation: "好药往往味苦难吃。比喻衷心的劝告，尖锐的批评，听起来觉得不舒服，但对改正缺点错误很有好处。", example: "我说的话可能你不愿意听，但是良药苦口，忠言逆耳，你还是听从我的劝告吧。" },
    { id: 123, idiom: "良莠不齐", pinyin: "liáng yǒu bù qí", english: "good and bad people intermingled", explanation: "莠：狗尾草，比喻坏人。指好人、坏人混在一起。", example: "现在到人才市场应聘的人虽然很多，但良莠不齐，用人单位要找到真正能胜任工作的人也不容易。" },
    { id: 124, idiom: "两袖清风", pinyin: "liǎng xiù qīng fēng", english: "free of corruption", explanation: "衣袖中除清风外，别无所有。比喻做官廉洁。", example: "做官，就应该两袖清风，为民造福。" },
    { id: 125, idiom: "了如指掌", pinyin: "liǎo rú zhǐ zhǎng", english: "to know inside out", explanation: "了：明白；指掌：指着手掌。形容对事物了解得非常清楚，象把东西放在手掌里给人家看一样。", example: "我从小在这儿长大，对这里的一切可说是了如指掌。" },
    { id: 126, idiom: "临渴掘井", pinyin: "lín kě jué jǐng", english: "start acting too late", explanation: "到口渴才掘井。比喻事先没有准备，临时才想办法。", example: "我们做事情要未雨绸缪，提前早作准备，不可临渴掘井。" },
    { id: 127, idiom: "炉火纯青", pinyin: "lú huǒ chún qīng", english: "attain the highest level to skill", explanation: "道士炼丹，认为炼到炉里发出纯青色的火焰就算成功了。后用来比喻功夫达到了纯熟完美的境界。", example: "刘师傅开车三十年了，他的开车技术已经达到炉火纯青的地步。" },
    { id: 128, idiom: "路不拾遗", pinyin: "lù bù shí yí", english: "honest in society", explanation: "遗：失物。路上没有人把别人丢失的东西捡走。形容社会风气好。", example: "新加坡虽然治安良好，但也还没有达到路不拾遗的地步。" },
    { id: 129, idiom: "洛阳纸贵", pinyin: "luò yáng zhǐ guì", english: "Said in praise of a man's writing", explanation: "洛阳：西晋等朝代的首都。洛阳市的纸价大涨。形容文章写得好，广泛流传风行一时。", example: "他的著作出版后深受好评，读者踊跃购买，大有洛阳纸贵之势。" },
    { id: 130, idiom: "络绎不绝", pinyin: "luò yì bù jué", english: "Endless and constant flow of traffic, people etc.", explanation: "形容人 马 车 船等来来往往，接连不断。", example: "综合度假胜地开张后，前来游玩的旅客络绎不绝。" },
    { id: 131, idiom: "毛遂自荐", pinyin: "máo suì zì jiàn", english: "Volunteer one's service.", explanation: "毛遂：战国时期赵国贵族平原君的一名食客。荐：推举。比喻自己推荐自己去做某事或担当某职。", example: "班上进行班长选举，小学当过班长的小明毛遂自荐，推荐自己做班长。" },
    { id: 132, idiom: "每况愈下", pinyin: "měi kuàng yù xià", english: "To become worse and worse; To go down the drain.", explanation: "比喻情况越来越坏。", example: "爸爸失业后，家里的经济状况就每况愈下。" },
    { id: 133, idiom: "门可罗雀", pinyin: "mén kě luó què", english: "No frequency of visitors.", explanation: "罗雀 ：张网捕鸟。门前可以张网捕鸟。形容门庭冷落，没有宾客来访", example: "附近的居民大多搬走了，这一带的商店顾客稀少，几乎门可罗雀。" },
    { id: 134, idiom: "面目全非", pinyin: "miàn mù quán fēi", english: "Be change or distorted beyond recognition.", explanation: "完全不是原来的样子，形容变化很大。", example: "小明的作文被老师改得面目全非，几乎不是他原来的作文了。" },
    { id: 135, idiom: "名列前茅", pinyin: "míng liè qián máo", english: "Be among the best of the successful candidates.", explanation: "比喻比赛或考试成绩排在前面。", example: "明华成绩优良，每次考试成绩都在全校名列前茅。" },
    { id: 136, idiom: "名落孙山", pinyin: "míng luò sūn shān", english: "Failed to pass the examination.", explanation: "孙山：人名。明子落在榜末孙山的后面。比喻没有考中 落选或没被录取。", example: "小李在选拔赛中名落孙山，没有机会代表学校出赛。" },
    { id: 137, idiom: "墨守成规", pinyin: "mò shǒu chéng guī", english: "stick to convention", explanation: "墨守：战国时墨翟善于守城，故称善守为墨守；成规：现成的规矩、制度。指思想固执保守，守着老规矩不放，不思改革进取。", example: "时代在不断进步，如果我们一直墨守成规，必将被时代淘汰。" },
    { id: 138, idiom: "目空一切", pinyin: "mù kōng yī qiè", english: "arrogant; disdainful", explanation: "一切都不放在眼里；形容非常狂妄。", example: "他自恃有才，目空一切，对谁都看不起。" },
    { id: 139, idiom: "逆水行舟", pinyin: "nì shuǐ xíng zhōu", english: "learning is either keep moving ahead or fall behind", explanation: "逆着水流的方向行船。比喻不努力就要后退。", example: "学习如逆水行舟，不进则退。" },
    { id: 140, idiom: "宁死不屈", pinyin: "nìng sǐ bù qū", english: "rather die tan surrender", explanation: "宁愿死也不屈服。", example: "面对日军的威逼利诱和死亡威胁，林谋盛宁死不屈，坚决不出卖自己的祖国。" },
    { id: 141, idiom: "拍案叫绝", pinyin: "pāi àn jiào jué", english: "thump the table and praise the excellence of a thing", explanation: "拍桌子叫好。形容非常赞赏。", example: "这座楼房的设计精妙绝伦，令人拍案叫绝。" },
    { id: 142, idiom: "蓬头垢面", pinyin: "péng tóu gòu miàn", english: "With unkempt hair and a dirty face, filthy appearance.", explanation: "蓬头：像蓬草那样散乱的头发。垢面：赃污的面孔。 形容头发散乱，脸上很脏。", example: "这个瘦削的小男孩蓬头垢面，站在街边向路人行乞。" },
    { id: 143, idiom: "破釜沉舟", pinyin: "pò fǔ chén zhōu", english: "Not to given a thought to giving up.", explanation: "釜：锅。舟：船。西楚霸王项羽被追兵围追时，下令摔破铁锅，弄沉渡船，与敌人决一死战。比喻痛下决心干到底。", example: "全体将士都抱着破釜沉舟的决心，要跟敌人决一死战。" },
    { id: 144, idiom: "欺世盗名", pinyin: "qī shì dào míng", english: "Gain fame by deceiving the public.", explanation: "欺骗世人，窃取名誉。", example: "这位名导演表面上品德高尚，实际上腐化堕落，欺世盗名，给青少年带来极坏的影响。" },
    { id: 145, idiom: "千钧一发", pinyin: "qiān jūn yī fà", english: "A critical moment", explanation: "比喻情况万分危急或异常要紧。", example: "正在千钧一发的时刻，一位行人奋不顾身跳进冰冷的河水中，救起了落水儿童。" },
    { id: 146, idiom: "前车之鉴", pinyin: "qián chē zhī jiàn", english: "learn lessons from other's mistakes", explanation: "比喻先前的失败，可以做为以后的教训。", example: "我们要学习人家成功的经验，也要以人家的失败作为前车之鉴，以警惕自己今后的工作不出同样的毛病。" },
    { id: 147, idiom: "前事不忘，后事之师", pinyin: "qián shì bù wàng, hòu shì zhī shī", english: "lessons learned from past experiences can guide one in the future.", explanation: "记取从前的经验教训，作为以后工作的借鉴", example: "正所谓"前事不忘，后事之师"，我们要记取这次失败的教训，争取下次实验成功。" },
    { id: 148, idiom: "潜移默化", pinyin: "qián yí mò huà", english: "influence someone's thinking", explanation: "指人的思想、性格、习惯因受各种因素的影响，在无形之中起了变化。", example: "母亲在平时生活中极具责任心的言行对我起到了潜移默化的作用，使我也成为一个有责任心的人。" },
    { id: 149, idiom: "巧夺天工", pinyin: "qiǎo duó tiān gōng", english: "wonderful workmanship", explanation: "指人工的精巧胜过天然制成,形容技艺十分高超。", example: "这个公园里的假山，造型新奇巧妙，真可说是巧夺天工。" },
    { id: 150, idiom: "青红皂白", pinyin: "qīng hóng zào bái", english: "The story and reasons behind something", explanation: "比喻事情的是非或原因、来龙去脉、是非曲直", example: "他不分青红皂白就打了我一顿，真是莫名其妙。" },
    { id: 151, idiom: "情同手足", pinyin: "qíng tóng shǒu zú", english: "like brothers; deep friendship", explanation: "比喻情谊深厚，如同兄弟一样。", example: "他们二人从小跟着一个师傅学徒，虽为异姓，却是情同手足。" },
    { id: 152, idiom: "人浮于事", pinyin: "rén fú yú shì", english: "overstaffed", explanation: "指工作中人员过多或人多事少。", example: "如今公司人浮于事，老板真准备裁员呢。" },
    { id: 153, idiom: "人杰地灵", pinyin: "rén jié dì líng", english: "greatness of a man brings glory to a place", explanation: "指杰出人物出生或到过的地方，就会成为名胜地区。", example: "这座小城人杰地灵，出了不少知名人士。" },
    { id: 154, idiom: "人尽其才", pinyin: "rén jìn qí cái", english: "make the most possible use of men", explanation: "每个人都可以充分的发挥自己的才能。", example: "合理的社会制度能让公民人尽其才，各取所需。" },
    { id: 155, idiom: "人云亦云", pinyin: "rén yún yì yún", english: "each the views of others; have no personal view", explanation: "人家怎么说，自己也跟着怎么说。指没有主见，只会随声附和。", example: "看待问题要有自己独到的见解，绝不可以人云亦云。" },
    { id: 156, idiom: "如火如荼", pinyin: "rú huǒ rú tú", english: "like a ranging fire; spread very quickly", explanation: "形容气势旺盛，气氛热烈。", example: "我校开展环保活动，从一开始便如火如荼，同学们的反应十分热烈。" },
    { id: 157, idiom: "如释重负", pinyin: "rú shì zhòng fù", english: "feel as if one has relieved a heavy load", explanation: "像放下重担那样。形容繁忙、紧张之后感到轻松愉快。", example: "工作终于如期完成，他如释重负地嘘了一口气。" },
    { id: 158, idiom: "入木三分", pinyin: "rù mù sān fēn", english: "profound; keen", explanation: "形容见解、议论、分析、刻画得很深刻。", example: "这部小说对人物的刻画栩栩如生，入木三分。" },
    { id: 159, idiom: "塞翁失马", pinyin: "sài wēng shī mǎ", english: "blessing in disguise", explanation: "比喻虽然暂时遭受损失，却也许因此得到好处，也指坏事可能会转变为好事", example: "塞翁失马，焉知非福。你第一次没考好，如从中吸取教训，以后会考得好一些。" },
    { id: 160, idiom: "三思而行", pinyin: "sān sī ér xíng", english: "don't act until one has thought about it carefully", explanation: "指经过反复考虑，然后再去做。", example: "做事情不可以莽撞，一定要三思而行。" },
    { id: 161, idiom: "杀鸡取卵", pinyin: "shā jī qǔ luǎn", english: "only look at advantages in the present and ignore the consequence in the future", explanation: "比喻贪图眼前的好处而不顾长远利益。", example: "这家公司为了一时之利而背弃诚信，无异于杀鸡取卵，以后再也没有人会与他们合作了。" },
    { id: 162, idiom: "伤天害理", pinyin: "shāng tiān hài lǐ", english: "outrageous", explanation: "伤、害：损害；天：天道；理：伦理。形容做事凶恶残忍，丧尽天良。", example: "每个人都容易看到别人做的坏事，却忽略自己做的事，有时比别人还更加伤天害理。" },
    { id: 163, idiom: "舍己为人", pinyin: "shě jǐ wèi rén", english: "sacrifice one's own interest for the sake of others.", explanation: "舍弃自己的利益去帮助别人。", example: "他经常主动去帮助功课较差的同学，常常很迟才回家，真是舍己为人。" },
    { id: 164, idiom: "实事求是", pinyin: "shí shì qiú shì", english: "practical and realistic", explanation: "指从实际对象出发，探求事物的内部联系及其发展的规律性，认识事物的本质。通常指按照事物的实际情况办事。", example: "总结经验要实事求是，不可弄虚做假。" },
    { id: 165, idiom: "事半功倍", pinyin: "shì bàn gōng bèi", english: "get twice the results with half the effort", explanation: "指做事得法，因而费力小，收效大。", example: "如能善用他的特长和经验，比较地容易获得事半功倍的效果。" },
    { id: 166, idiom: "视死如归", pinyin: "shì sǐ rú guī", english: "very brave", explanation: "把死看得象回家一样平常。形容不怕牺牲生命。", example: "我们已经是视死如归，我们大踏步地走着我们的大路。" },
    { id: 167, idiom: "守望相助", pinyin: "shǒu wàng xiāng zhù", english: "mutual help and protection", explanation: "守望：防守了望。为了对付来犯的敌人或意外的灾祸，邻近各村落互相警戒，互相援助。", example: "邻居彼此应该守望相助，彼此互相照应门户安全。" },
    { id: 168, idiom: "守株待兔", pinyin: "shǒu zhū dài tù", english: "trust on luck for opportunities", explanation: "株：露出地面的树根。原比喻希图不经过努力而得到成功的侥幸心理。现也比喻死守狭隘经验，不知变通。", example: "想靠买彩票发财就像守株待兔，终究不是正常的生活态度。" },
    { id: 169, idiom: "熟能生巧", pinyin: "shú néng shēng qiǎo", english: "practice makes perfect", explanation: "熟练了，就能找到窍门。", example: "要想掌握技术，只有勤学苦练，才能熟能生巧。" },
    { id: 170, idiom: "水到渠成", pinyin: "shuǐ dào qú chéng", english: "when conditions are right, success will come naturally", explanation: "渠：水道。水流到的地方自然形成一条水道。比喻条件成熟，事情自然会成功。", example: "这次的合约我们已经做了万全的准备，现在就等水到渠成，完成手续。" },
    { id: 171, idiom: "水落石出", pinyin: "shuǐ luò shí chū", english: "the truth comes out", explanation: "水落下去，水底的石头就露出来。比喻事情的真相完全显露出来。", example: "这件事情既然已经水落石出了，谣言当然就不攻自破了。" },
    { id: 172, idiom: "司空见惯", pinyin: "sī kōng jiàn guàn", english: "common sight", explanation: "司空：古代官名。指某事常见，不足为奇。", example: "他参加比赛得奖早已司空见惯，不得奖才是新闻。" },
    { id: 173, idiom: "四面楚歌", pinyin: "sì miàn chǔ gē", english: "surrounded by enemies", explanation: "比喻陷入四面受敌、孤立无援的境地。", example: "因为战略错误，造成前线军队陷入四面楚歌的困境。" },
    { id: 174, idiom: "损人利己", pinyin: "sǔn rén lì jǐ", english: "harm others to benefit oneself", explanation: "损害别人，使自己得到好处。", example: "他宁可失去出国的机会，也不做损人利己的事。" },
    { id: 175, idiom: "螳臂当车", pinyin: "táng bì dāng chē", english: "overrate oneself and try to hold back an overwhelming force", explanation: "当：阻挡。螳螂举起前肢企图阻挡车子前进。比喻做力量做不到的事情，必然失败", example: "他这种螳臂当车的做法简直就是自不量力，自讨苦吃。" },
    { id: 176, idiom: "桃李满天下", pinyin: "táo lǐ mǎn tiān xià", english: "have pupils everywhere", explanation: "桃李：指培养的后辈或所教的学生。比喻学生很多，各地都有。", example: "李老师教了一辈子的书，学生遍布全世界，真是桃李满天下。" },
    { id: 177, idiom: "天渊之别", pinyin: "tiān yuān zhī bié", english: "totally different", explanation: "天和地，一极在上，一极在下。比喻差别极大。", example: "他们俩虽是双胞胎，但是性格却有天渊之别，一个好动，一个好静。" },
    { id: 178, idiom: "挑拨离间", pinyin: "tiǎo bō lí jiàn", english: "drive a wedge between people", explanation: "搬弄是非，使别人不团结。", example: "他们俩之所以会闹翻是因为有人在挑拨离间。" },
    { id: 179, idiom: "铤而走险", pinyin: "tǐng ér zǒu xiǎn", english: "take risks out of desperation", explanation: "指因无路可走而采取冒险行动。", example: "为了偿还债务，他竟铤而走险，去走私犯毒，结果越陷越深。" },
    { id: 180, idiom: "同甘共苦", pinyin: "tóng gān gòng kǔ", english: "to share life's joys and sorrows", explanation: "共同享受幸福，共同担当艰苦。", example: "夫妻若能同甘共苦，生活一定幸福美满。" },
    { id: 181, idiom: "同流合污", pinyin: "tóng liú hé wū", english: "associate with an evil person; partner in crime", explanation: "随着坏人一起做坏事。", example: "虽然他身处恶劣环境，但他绝对不会跟这些坏人同流合污的。" },
    { id: 182, idiom: "同心协力", pinyin: "tóng xīn xié lì", english: "work together with one heart", explanation: "协：合。团结一致，共同努力做事。", example: "只要大家同心协力，一定能达致目标，把事情做好。" },
    { id: 183, idiom: "同舟共济", pinyin: "tóng zhōu gòng jì", english: "collaborate towards same goal", explanation: "比喻同心协力，共同渡过困难。", example: "在这个艰难的处境中，我们唯有同舟共济，才可以摆脱困境。" },
    { id: 184, idiom: "徒劳无功", pinyin: "tú láo wú gōng", english: "make a futile effort", explanation: "白费力气，没有成就或好处。也说徒劳无益。", example: "做事必须用正确的方法，不能蛮干，否则就可能徒劳无功。" },
    { id: 185, idiom: "退避三舍", pinyin: "tuì bì sān shè", english: "to give away in face of superior strength", explanation: "舍：古时行军三十里叫一舍。主动退让九十里。比喻退和回避，避免冲突。", example: "只要见到那个不讲理的恶霸，大家立刻退避三舍，以免惹上不必要的麻烦。" },
    { id: 186, idiom: "万古流芳", pinyin: "wàn gǔ liú fāng", english: "achieve immortal fame", explanation: "形容一个伟大人物，他的名誉世世代代流传下来。", example: "新加坡抗日英雄林谋盛的名字，万古流芳，永垂不朽。" },
    { id: 187, idiom: "万事俱备，只欠东风", pinyin: "wàn shì jù bèi, zhǐ qiàn dōng fēng", english: "everything is ready except for one crucial item", explanation: "三国时期，周瑜计划火攻曹操，一切都准备好了，只差东风没刮起来，不能顺风放火。后比喻样样都准备好了，只差最后一个重要条件。", example: "这件计划的细节都已经拟好了，只差经理决定是否采纳了。" },
    { id: 188, idiom: "望尘莫及", pinyin: "wàng chén mò jí", english: "too far behind to catch up; be out of one's league", explanation: "只望见走在前面的人带起的尘土而赶不上。比喻远远落后。", example: "他在各方面的成就都那么突出，成绩一般的我真是望尘莫及。" },
    { id: 189, idiom: "忘恩负义", pinyin: "wàng ēn fù yì", english: "ungrateful", explanation: "恩：恩惠；负：违背；义：情谊，忘记别人对自己的恩情，做出对不起别人的事。", example: "我们做人应该知恩图报，不能忘恩负义。" },
    { id: 190, idiom: "危言耸听", pinyin: "wēi yán sǒng tīng", english: "say frightening things to cause alarm", explanation: "故意说吓人的话使听的人吃惊。", example: "你别危言耸听了，你的病情并不如你所说的那么严重。" },
    { id: 191, idiom: "为非作歹", pinyin: "wéi fēi zuò dǎi", english: "do evil; commit crimes", explanation: "做各种坏事。", example: "他不务正业，整天跟那一群流氓在一起为非作歹。" },
    { id: 192, idiom: "为虎作伥", pinyin: "wèi hǔ zuò chāng", english: "to help a villain do evil", explanation: "伥：鬼名。比喻做恩人的帮凶，帮助恶人做坏事。", example: "日军侵略时期，许多人去做日军的间谍，为虎作伥，残害自己的同胞。" },
    { id: 193, idiom: "未雨绸缪", pinyin: "wèi yǔ chóu móu", english: "take precautions", explanation: "趁着天气没下雨，先修缮房屋门窗。比喻事先做好准备。", example: "做事若能未雨绸缪，就不会等到急时才手忙脚乱了。" },
    { id: 194, idiom: "温故知新", pinyin: "wēn gù zhī xīn", english: "understand the present by reviewing the past", explanation: "温：温习。故：旧的。温习旧的知识，能够得到新的理解和体会。也指回忆过去，认识现在。", example: "读过的书，有空时也可以拿出来再读，所谓温故知新，这对学习是很有益处的。" },
    { id: 195, idiom: "温文尔雅", pinyin: "wēn wén ěr yǎ", english: "cultured and refined", explanation: "态度温和，举止文雅。", example: "他温文尔雅，风度翩翩，真是一表人才。" },
    { id: 196, idiom: "闻鸡起舞", pinyin: "wén jī qǐ wǔ", english: "diligent and self-disciplined", explanation: "听到鸡叫就起来舞剑。形容发奋有为，也比喻有志之士，及时振作。", example: "祖逖闻鸡起舞，后来建功立业，终于成为国家的栋梁之才。" },
    { id: 197, idiom: "卧薪尝胆", pinyin: "wò xīn cháng dǎn", english: "Descriptive of persons who suffer hardship patiently and plan for restoration of their undertakings.", explanation: "薪：柴草。睡觉睡在柴草上，吃饭睡觉都尝一尝苦胆。形容人刻苦自励，发奋图强或决心报仇雪耻。", example: "哥哥生意失败后并没有灰心丧气，经过三年卧薪尝胆，他终于重新起步，东山再起。" },
    { id: 198, idiom: "乌合之众", pinyin: "wū hé zhī zhòng", english: "A disorderly band; A motley crowd", explanation: "乌：乌鸦。像暂时聚合的一群乌鸦。比喻临时凑集的、毫无组织纪律的一群人。", example: "没有英明领导的人们，就是一群乌合之众。" },
    { id: 199, idiom: "乌烟瘴气", pinyin: "wū yān zhàng qì", english: "Foul atmosphere; a pestilential atmosphere", explanation: "乌：黑。瘴气：南方的林中的湿热空气。原指环境污染。多比喻环境嘈杂；秩序混乱；风气不正或社会黑暗。", example: "会议还没开始，有些人高声谈话，有些人不停抽烟，会议室里一片乌烟瘴气。" },
    { id: 200, idiom: "无可厚非", pinyin: "wú kě hòu fēi", english: "Give no cause for much criticism.", explanation: "厚：深重；非：非议，否定。不能过分责备。指说话做事虽有缺点，但还有可取之处，应予谅解。", example: "父母疼爱孩子是人之常情，无可厚非，但过分溺爱，就不是一件好事了。" },
    { id: 201, idiom: "五体投地", pinyin: "wǔ tǐ tóu dì", english: "Somebody in admiration", explanation: "五体：头和四肢；投地：着地。两手、两膝和头一起着地。原为古代印度最恭敬的一种致敬仪式。后比喻心悦服或敬佩到了极点。", example: "球迷们对球王马拉多纳的球技佩服得五体投地。" },
    { id: 202, idiom: "无微不至", pinyin: "wú wēi bù zhì", english: "meticulous", explanation: "微：微细；至：到。没有一处细微的地方不照顾到。形容关怀、照顾得非常细心周到。", example: "在妈妈无微不至地照顾下，小明的病很快痊愈了。" },
    { id: 203, idiom: "相辅相成", pinyin: "xiāng fǔ xiāng chéng", english: "To complement each other; To reciprocate and complement", explanation: "辅：辅助，帮助。指两件事物互相辅助、互相配合。", example: "读和写是学好语文的两种必须途径，他们之间是相辅相成的，缺一不可。" },
    { id: 204, idiom: "心猿意马", pinyin: "xīn yuán yì mǎ", english: "Restless and whimsical; Fanciful and Fickle", explanation: "心思像猿猴跳跃、快马奔驰那样控制不住。形容心思不定、不专。", example: "上课应该专心听讲，不要心猿意马，东张西望。" },
    { id: 205, idiom: "幸灾乐祸", pinyin: "xìng zāi lè huò", english: "Take pleasure in other's misfortune", explanation: "别人遭受灾祸，自己反而高兴。", example: "路边有一位老婆婆摔倒了，小强不但不上前扶他起来，还幸灾乐祸笑个不停，真不应该。" },
    { id: 206, idiom: "袖手旁观", pinyin: "xiù shǒu páng guān", english: "Look on or stand by with no intention to interfere or help", explanation: "把手放在袖子里，站在一旁观看。比喻置身事外，不过问或不帮助。", example: "朋友有了困难，我们不该袖手旁观，应该尽力帮忙才是。" },
    { id: 207, idiom: "胸有成竹", pinyin: "xiōng yǒu chéng zhú", english: "To be well-prepared and ready for a situation", explanation: "画竹子时心理已有竹子的形象。比喻事前已有了主意，因而显得镇静而有把握。", example: "对这次的考试，小华准备充足，胸有成竹，一点也不紧张。" },
    { id: 208, idiom: "虚怀若谷", pinyin: "xū huái ruò gǔ", english: "Be very modest; Be extremely open-minded", explanation: "虚怀：谦虚的胸怀；谷：山谷。谦虚的胸怀像山谷一样深广。形容非常谦虚。", example: "李校长是个谦虚谨慎、虚怀若谷的教育家。" },
    { id: 209, idiom: "悬崖勒马", pinyin: "xuán yá lè mǎ", english: "To come to a realization before it is too late", explanation: "悬崖：高而陡的山崖；勒马：拉进缰绳，使马停下。比喻到了危险的边缘及时醒悟回头。", example: "小明成天跟那些不良少年在一起热时，如果不悬崖勒马，后果将会不堪设想。" },
    { id: 210, idiom: "削足适履", pinyin: "xuē zú shì lǚ", english: "To use impractical solution or measures to solve a problem", explanation: "履：鞋子。削小了脚使适合鞋的尺寸。比喻没有原则地迁就或勉强凑和。", example: "你必须坚持原则，削足适履于事无补，无法把问题解决。" },
    { id: 211, idiom: "雪中送炭", pinyin: "xuě zhōng sòng tàn", english: "Provide timely help", explanation: "雪天里给人送木炭取暖。比喻在别人急需时给以帮助。", example: "在他人困难时及时伸出援手，无异于雪中送炭，对方一定会十分感激。" },
    { id: 212, idiom: "循循善诱", pinyin: "xún xún shàn yòu", english: "Be good at providing systematic guidance", explanation: "循循：有步骤的样子；善：善于；诱：引导。指善于有步骤地进行引导、教育。", example: "林老师对于犯错的同学，总是循循善诱，从不轻易施加体罚。" },
    { id: 213, idiom: "掩耳盗铃", pinyin: "yǎn ěr dào líng", english: "Deceive oneself; Bury one's head in the sand", explanation: "掩：遮盖。用手盖住自己的耳朵去偷铃。比喻自己欺骗自己。", example: "你编造了这么离谱的谎话，还以为能骗过所有的人，无疑是掩耳盗铃，自欺欺人。" },
    { id: 214, idiom: "夜郎自大", pinyin: "yè láng zì dà", english: "Parochial arrogance", explanation: "夜郎：汉代西南地区的一个小国。比喻孤陋寡闻而又狂妄自大。", example: "你应该多出去见见世面，才不会像现在这样自以为了不起，夜郎自大。" },
    { id: 215, idiom: "一败涂地", pinyin: "yī bài tú dì", english: "Suffer a crushing defeat", explanation: "涂地：涂抹满地。形容失败得很惨。也形容处境十分狼狈或是情怀到无法收拾的地步。", example: "陈委员狂妄自大，不得民心，在这次选举中输得一败涂地，得票极少。" },
    { id: 216, idiom: "一帆风顺", pinyin: "yī fān fēng shùn", english: "To proceed smoothly without a hitch", explanation: "船只扬起帆，顺风行驶。比喻旅程、工作或境遇非常顺利。", example: "他认真尽责，事业一帆风顺，不到三十岁已经成为高阶主管了。" },
    { id: 217, idiom: "一鼓作气", pinyin: "yī gǔ zuò qì", english: "Press on to the finish without help; Get something done in one vigorous effort.", explanation: "鼓：敲战鼓；作：振作。指作战时，第一次敲鼓，可以鼓起士兵的勇气。比喻做事鼓足干劲，一口气完成。", example: "小强回到家里，便一鼓作气把功课做完，才和朋友们出去打球。" },
    { id: 218, idiom: "一见如故", pinyin: "yī jiàn rú gù", english: "Able to become friendly and to get along easily at the first meeting.", explanation: "故：老朋友。初次见面就像老朋友一样。形容很投合，很要好。", example: "经过老王介绍，老刘和小林一见如故，无所不谈地聊了起来。" },
    { id: 219, idiom: "一鸣惊人", pinyin: "yī míng jīng rén", english: "(Of an obscure person) amaze the world with a single brilliant feat", explanation: "鸣：叫。一叫就惊动人。比喻平时不为人所知，突然有惊人的表现或做出惊人之举。", example: "大明一向成绩平平，没想到今年升上中学后表现一鸣惊人，名列前茅。" },
    { id: 220, idiom: "一暴十寒", pinyin: "yī pù shí hán", english: "Not motivated to do work; Spend more time lazing around than work .", explanation: "暴（pù）晒。晒一天，冻十天。比喻学习工作没有恒心，努力的时候少，懒惰的时候多。", example: "成功靠的是毅力和恒心，像你这样一暴十寒，怎么会有成就呢？" },
    { id: 221, idiom: "一视同仁", pinyin: "yī shì tóng rén", english: "Treat equally without discrimination.", explanation: "一视：一样看待；仁：仁爱。", example: "这个公司的老板对员工一视同仁，勤奋的职员都有机会获得升职。" },
    { id: 222, idiom: "一意孤行", pinyin: "yī yì gū xíng", english: "To do something against the advice of others; Individualistic.", explanation: "孤：独自。固执地按照自己的心意做事。比喻不听别人的意见，独断独行。", example: "你应该认真考虑大家的意见，不应再这样一意孤行，蛮干下去。" },
    { id: 223, idiom: "一针见血", pinyin: "yī zhēn jiàn xiě", english: "Hit the nail on the head; Direct and to the point.", explanation: "比喻说话简要，一下子就说中要害。", example: "他的批评一针见血，切中小王的要害，令假公济私的小王很不安。" },
    { id: 224, idiom: "以卵击石", pinyin: "yǐ luǎn jī shí", english: "Throw an egg against a rock- Court defeat by fighting against overwhelming odds.", explanation: "卵：蛋。拿蛋去打石头。比喻以弱敌强，自取灭亡。", example: "他是我国羽毛球单打冠军，林教练派你去和他对阵，岂不是以卵击石？" },
    { id: 225, idiom: "以身作则", pinyin: "yǐ shēn zuò zé", english: "Set an example.", explanation: "则：榜样。用自己的实际行动做榜样。", example: "他不但教育子女要养成看书的好习惯，而且以身作则，每天陪子女阅读书报。" },
    { id: 226, idiom: "以牙还牙", pinyin: "yǐ yá huán yá", english: "An eye for an eye.", explanation: "别人用牙齿咬我，我也用牙齿咬他。比喻用对方使用的手段回击对方。", example: "每次我做错事，他就得理不饶人；这次他做错了事，我决定以牙还牙，让他尝尝被欺负的滋味。" },
    { id: 227, idiom: "因材施教", pinyin: "yīn cái shī jiào", english: "To suit the teaching to the ability of the pupil.", explanation: "因：根据。根据不同的对象或智力的高低而采取不同的教育方法。", example: "校长要求每位老师能因材施教，使不同程度的学生都能发展他们最大的潜能。" },
    { id: 228, idiom: "饮水思源", pinyin: "yǐn shuǐ sī yuán", english: "To always be grateful and thankful.", explanation: "喝水时想到水源。比喻不忘本。", example: "你能有今天的成就，应该饮水思源，感谢王老师的指导与帮助。" },
    { id: 229, idiom: "迎刃而解", pinyin: "yíng rèn ér jiě", english: "To pin-point the core or source of the problem so that subsequent related problems are easily solved.", explanation: "迎：对着；刃：刀口；解：分开。像劈竹子一样，第一节碰上刀口裂开后，下面的就顺着裂开了。比喻主要问题解决了，其他问题就容易办。也比喻问题顺利解决。", example: "这个关键的难题一解决，其他问题也就迎刃而解了。" },
    { id: 230, idiom: "应接不暇", pinyin: "yìng jiē bù xiá", english: "Too busy to attend to all.", explanation: "应接：应付、接待；暇：空闲。形容处处是美景，来不及观赏。也形容事情繁多，应付不过来。", example: "学校假期中，每天前来借书的学生很多，图书馆的工作人员忙得不可开交，应接不暇。" },
    { id: 231, idiom: "与虎谋皮", pinyin: "yǔ hǔ móu pí", english: "Request somebody to act against his own interest.", explanation: "谋：谋求、商量。 同老虎商量，要剥下它的皮。比喻商量的事危害对方切身利益，绝对办不成。", example: "这间店的生意越来越好，你想要店主转让，这简直是与虎谋皮！" },
    { id: 232, idiom: "与日俱增", pinyin: "yǔ rì jù zēng", english: "Grow with each passing day.", explanation: "与:跟；日：时间；俱：一同。随着时间一同增长。形容知识不断增加或增长很快。", example: "随着服务质量的改善，那间餐馆的生意蒸蒸日上，营业额与日俱增。" },
    { id: 233, idiom: "缘木求鱼", pinyin: "yuán mù qiú yú", english: "A fruitless approach.", explanation: "缘：沿，顺着；缘木:爬树。爬上树去找鱼。比喻方向或方法不对，不可能达到目的。", example: "这孩子根本没有音乐天分，家长硬要他学音乐，简直是缘木求鱼，白费心机。" },
    { id: 234, idiom: "约法三章", pinyin: "yuē fǎ sān zhāng", english: "Make a few simple rules to be observed by all concerned.", explanation: "约：约定；法：法令；章:条目。一定三条法令。指订立为大家所遵守的规章条款。", example: "考试期间爸爸和我约法三章，不许我看电视连续剧。" },
    { id: 235, idiom: "再接再厉", pinyin: "zài jiē zài lì", english: "To continue to put more effort.", explanation: "比喻继续努力，毫不放松。", example: "在进入半决赛后，陈教练鼓励全体球员再接再厉，争取进入大决赛。" },
    { id: 236, idiom: "真知灼见", pinyin: "zhēn zhī zhuó jiàn", english: "Real knowledge and deep insight.", explanation: "灼：明白，透彻。正确而透彻的见解。", example: "黄教授所发表的言论确实是真知灼见，深受学术界的赞誉。" },
    { id: 237, idiom: "蒸蒸日上", pinyin: "zhēng zhēng rì shàng", english: "becoming more prosperous with each passing day", explanation: "蒸蒸:上升、兴盛的样子。形容事业一天天向上发展。", example: "我们伟大的祖国生机勃勃，蒸蒸日上。" },
    { id: 238, idiom: "执迷不悟", pinyin: "zhí mí bù wù", english: "obstinately stick to a wrong course", explanation: "执：固执，坚持；迷：迷惑；悟：觉悟。坚持错误而不觉悟。", example: "尽管老师苦口婆心地劝他改过自新，但他仍执迷不悟。" },
    { id: 239, idiom: "纸上谈兵", pinyin: "zhǐ shàng tán bīng", english: "a solution that is only a theory or plan may not work when put into action", explanation: "在纸面上谈论打仗。比喻空谈理论，不能解决实际问题。也比喻空谈不能成为现实。", example: "理论不能联系实际，只会纸上谈兵，是不可能成功的。" },
    { id: 240, idiom: "志同道合", pinyin: "zhì tóng dào hé", english: "like-minded; same idea", explanation: "志向相同,意见一致", example: "我和小华自小相识，兴趣爱好一致，是志同道合的好朋友。" },
    { id: 241, idiom: "志在四方", pinyin: "zhì zài sì fāng", english: "High aspiration or ambition.", explanation: "志：志向；四方：各处天下、国家。形容有远大的志向和抱负。", example: "男儿志在四方，将来有机会我要到国外去发展事业。" },
    { id: 242, idiom: "州官放火", pinyin: "zhōu guān fàng huǒ", english: "One may steal a horse while another may not look over the hedge.", explanation: "比喻在上的人自己可以胡作非为，老百姓或普通人却连正当活动也要受到限制。", example: "经理不许职员把任何过期的旧报纸带回家，自己却每天把当天的报纸带走，真是只许州官放火，不许百姓点灯。" },
    { id: 243, idiom: "装聋作哑", pinyin: "zhuāng lóng zuò yǎ", english: "pretend to be dumb and deaf; feign ignorance", explanation: "指故意不理睬，只当不知道。", example: "对社会上的不良风气，不能装聋作哑，不闻不问。" },
    { id: 244, idiom: "自暴自弃", pinyin: "zì bào zì qì", english: "to give up", explanation: "暴：糟蹋、损害；弃：鄙弃。自己瞧不起自己，甘于落后或堕落。", example: "虽然这次比赛失败了，但我们不能自暴自弃，要继续努力，争取下次赢回来。" },
    { id: 245, idiom: "自食其力", pinyin: "zì shí qí lì", english: "to support oneself by own labor; earn own living", explanation: "依靠自己的劳动所得来生活。", example: "年青人要自食其力，总想着依靠父母是不会有出息的。" },
    { id: 246, idiom: "自投罗网", pinyin: "zì tóu luó wǎng", english: "to walk into a trap", explanation: "自己主动钻入对方布下的陷阱中。也指自取祸害,自作自受。", example: "这名毒犯有眼无珠，竟然向警方兜售毒品，真是自投罗网。" },
    { id: 247, idiom: "自相矛盾", pinyin: "zì xiāng máo dùn", english: "To contradict oneself", explanation: "比喻语言、行动前后不一致或互相抵触。", example: "将军原本主张抵抗到底，现在却又主张同敌人讲和，真是自相矛盾。" },
    { id: 248, idiom: "作壁上观", pinyin: "zuò bì shàng guān", english: "be a bystander", explanation: "壁：壁垒。原指双方交战，自己站在壁垒上旁观。后多比喻站在一旁看着，不动手帮助。", example: "他看到别人有困难，总是作壁上观，从来也不会伸出援手。" },
    { id: 249, idiom: "坐享其成", pinyin: "zuò xiǎng qí chéng", english: "sit idle and enjoy the fruits of other's labor", explanation: "享：享受；成：成果。自己不出力而享受别人取得的成果。", example: "李经理从没出过力，计划完成后他却坐享其成，将功劳归于自己，大家都感到愤愤不平。" },
    { id: 250, idiom: "坐井观天", pinyin: "zuò jǐng guān tiān", english: "have a very narrow view", explanation: "坐在井底看天。比喻眼界小，见识少。", example: "他从未离开过这个小村庄，对世界的认识就像坐井观天一样有限。" }
];

// 游戏状态
let currentGame = 'learn';
let currentIdiomIndex = 0;
let quizScore = { correct: 0, total: 0 };
let selectedMatchCards = [];
let matchedPairs = 0;
let soundEnabled = true;
let currentRange = { start: 1, end: 10 };
let currentIdioms = idioms.filter(idiom => idiom.id >= currentRange.start && idiom.id <= currentRange.end);
let deferredPrompt = null;

// DOM元素
const gameModes = document.querySelectorAll('.game-mode');
const gameBtns = document.querySelectorAll('.game-btn');
const progressBar = document.getElementById('progress');
const scoreDisplay = document.getElementById('score');
const soundToggle = document.getElementById('sound-toggle');
const rangeStart = document.getElementById('range-start');
const rangeEnd = document.getElementById('range-end');
const applyRange = document.getElementById('apply-range');
const rangePresets = document.querySelectorAll('.range-preset');
const installPrompt = document.getElementById('install-prompt');
const installBtn = document.getElementById('install-btn');
const dismissInstall = document.getElementById('dismiss-install');

// 学习模式元素
const currentIdiomElement = document.getElementById('current-idiom');
const currentPinyinElement = document.getElementById('current-pinyin');
const currentMeaningElement = document.getElementById('current-meaning');
const currentExplanationElement = document.getElementById('current-explanation');
const currentExampleElement = document.getElementById('current-example');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');

// 选择题测试元素
const quizMode = document.getElementById('quiz-mode');
const quizQuestion = document.getElementById('quiz-question');
const quizMeaning = document.getElementById('quiz-meaning');
const quizOptions = document.getElementById('quiz-options');
const quizNextBtn = document.getElementById('quiz-next');

// 图片匹配游戏元素
const matchMode = document.getElementById('match-mode');
const matchContainer = document.getElementById('match-container');
const matchNextBtn = document.getElementById('match-next');

// 音效元素
const correctSound = document.getElementById('correct-sound');
const incorrectSound = document.getElementById('incorrect-sound');
const matchSound = document.getElementById('match-sound');
const completeSound = document.getElementById('complete-sound');
const clickSound = document.getElementById('click-sound');

// 初始化应用
function initApp() {
    // 设置游戏模式切换
    gameBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const game = btn.getAttribute('data-game');
            switchGameMode(game);
            
            // 更新活动按钮
            gameBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            // 播放点击音效
            playSound('click');
        });
    });

    // 音效切换
    soundToggle.addEventListener('click', () => {
        soundEnabled = !soundEnabled;
        soundToggle.innerHTML = soundEnabled ? 
            '<i class="fas fa-volume-up"></i>' : 
            '<i class="fas fa-volume-mute"></i>';
        playSound('click');
    });

    // 范围选择
    applyRange.addEventListener('click', applyIdiomRange);
    
    rangePresets.forEach(preset => {
        preset.addEventListener('click', () => {
            const start = parseInt(preset.getAttribute('data-start'));
            const end = parseInt(preset.getAttribute('data-end'));
            rangeStart.value = start;
            rangeEnd.value = end;
            applyIdiomRange();
            
            // 更新预设活动状态
            rangePresets.forEach(p => p.classList.remove('active'));
            preset.classList.add('active');
            
            playSound('click');
        });
    });

    // 学习模式导航
    prevBtn.addEventListener('click', showPreviousIdiom);
    nextBtn.addEventListener('click', showNextIdiom);

    // 键盘导航支持
    document.addEventListener('keydown', (e) => {
        if (currentGame === 'learn') {
            if (e.key === 'ArrowLeft') {
                showPreviousIdiom();
            } else if (e.key === 'ArrowRight') {
                showNextIdiom();
            }
        }
    });

    // 选择题测试导航
    quizNextBtn.addEventListener('click', generateQuizQuestion);

    // 图片匹配游戏导航
    matchNextBtn.addEventListener('click', generateMatchGame);

    // 安装提示
    installBtn.addEventListener('click', installApp);
    dismissInstall.addEventListener('click', () => {
        installPrompt.classList.add('hidden');
    });

    // 监听安装提示
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        installPrompt.classList.remove('hidden');
    });

    // 初始显示
    updateLearnMode();
    generateQuizQuestion();
    generateMatchGame();
    updateProgress();

    // 注册Service Worker
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('/sw.js')
                .then((registration) => {
                    console.log('ServiceWorker 注册成功: ', registration.scope);
                })
                .catch((error) => {
                    console.log('ServiceWorker 注册失败: ', error);
                });
        });
    }
}

// 播放音效
function playSound(type) {
    if (!soundEnabled) return;
    
    try {
        const sound = {
            'correct': correctSound,
            'incorrect': incorrectSound,
            'match': matchSound,
            'complete': completeSound,
            'click': clickSound
        }[type];
        
        if (sound) {
            sound.currentTime = 0;
            sound.play().catch(e => console.log('音效播放失败:', e));
        }
    } catch (e) {
        console.log('音效播放错误:', e);
    }
}

// 安装应用
function installApp() {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
                console.log('用户接受了安装提示');
                installPrompt.classList.add('hidden');
            }
            deferredPrompt = null;
        });
    }
}

// 应用成语范围
function applyIdiomRange() {
    const start = parseInt(rangeStart.value);
    const end = parseInt(rangeEnd.value);
    
    if (start < 1 || start > 250 || end < 1 || end > 250 || start > end) {
        alert('请输入有效的范围（1-250，且起始值不大于结束值）');
        return;
    }
    
    currentRange = { start, end };
    currentIdioms = idioms.filter(idiom => idiom.id >= start && idiom.id <= end);
    
    // 重置游戏状态
    currentIdiomIndex = 0;
    quizScore = { correct: 0, total: 0 };
    selectedMatchCards = [];
    matchedPairs = 0;
    
    // 更新显示
    updateLearnMode();
    generateQuizQuestion();
    generateMatchGame();
    updateProgress();
    updateScoreDisplay();
    
    playSound('click');
}

// 切换游戏模式
function switchGameMode(game) {
    currentGame = game;
    
    // 隐藏所有游戏模式
    gameModes.forEach(mode => {
        mode.classList.add('hidden');
    });
    
    // 显示当前游戏模式
    document.getElementById(`${game}-mode`).classList.remove('hidden');
    
    // 更新进度条
    updateProgress();
}

// 更新学习模式
function updateLearnMode() {
    if (currentIdioms.length === 0) return;
    
    const idiom = currentIdioms[currentIdiomIndex];
    currentIdiomElement.textContent = idiom.idiom;
    currentPinyinElement.textContent = idiom.pinyin;
    currentMeaningElement.textContent = idiom.english;
    currentExplanationElement.textContent = idiom.explanation;
    currentExampleElement.textContent = idiom.example;
    
    // 更新按钮状态
    prevBtn.disabled = currentIdiomIndex === 0;
    nextBtn.disabled = currentIdiomIndex === currentIdioms.length - 1;
    
    updateProgress();
}

// 显示上一个成语
function showPreviousIdiom() {
    if (currentIdiomIndex > 0) {
        currentIdiomIndex--;
        updateLearnMode();
        playSound('click');
    }
}

// 显示下一个成语
function showNextIdiom() {
    if (currentIdiomIndex < currentIdioms.length - 1) {
        currentIdiomIndex++;
        updateLearnMode();
        playSound('click');
    }
}

// 生成选择题测试
function generateQuizQuestion() {
    if (currentIdioms.length === 0) return;
    
    // 随机选择一个成语作为正确答案
    const correctIndex = Math.floor(Math.random() * currentIdioms.length);
    const correctIdiom = currentIdioms[correctIndex];
    
    // 生成错误选项
    const incorrectOptions = [];
    while (incorrectOptions.length < 3) {
        const randomIndex = Math.floor(Math.random() * currentIdioms.length);
        if (randomIndex !== correctIndex && !incorrectOptions.includes(currentIdioms[randomIndex].idiom)) {
            incorrectOptions.push(currentIdioms[randomIndex].idiom);
        }
    }
    
    // 合并选项并随机排序
    const allOptions = [correctIdiom.idiom, ...incorrectOptions];
    shuffleArray(allOptions);
    
    // 更新问题
    quizMeaning.textContent = correctIdiom.english;
    
    // 清空选项容器
    quizOptions.innerHTML = '';
    
    // 添加选项
    allOptions.forEach(option => {
        const optionElement = document.createElement('div');
        optionElement.className = 'option';
        optionElement.textContent = option;
        optionElement.addEventListener('click', () => checkAnswer(option, correctIdiom.idiom));
        quizOptions.appendChild(optionElement);
    });
    
    // 更新分数显示
    updateScoreDisplay();
}

// 检查答案
function checkAnswer(selected, correct) {
    const options = document.querySelectorAll('.option');
    
    options.forEach(option => {
        option.classList.remove('correct', 'incorrect');
        
        if (option.textContent === correct) {
            option.classList.add('correct');
        }
        
        if (option.textContent === selected && selected !== correct) {
            option.classList.add('incorrect');
        }
    });
    
    // 更新分数
    quizScore.total++;
    if (selected === correct) {
        quizScore.correct++;
        playSound('correct');
    } else {
        playSound('incorrect');
    }
    
    updateScoreDisplay();
}

// 生成图片匹配游戏
function generateMatchGame() {
    if (currentIdioms.length < 4) {
        matchContainer.innerHTML = '<div class="completion-message">当前范围成语数量不足4个，无法进行匹配游戏</div>';
        return;
    }
    
    // 清空匹配容器和状态
    matchContainer.innerHTML = '';
    selectedMatchCards = [];
    matchedPairs = 0;
    
    // 随机选择4组成语进行匹配
    const selectedIdioms = [];
    while (selectedIdioms.length < 4) {
        const randomIndex = Math.floor(Math.random() * currentIdioms.length);
        if (!selectedIdioms.includes(currentIdioms[randomIndex])) {
            selectedIdioms.push(currentIdioms[randomIndex]);
        }
    }
    
    // 创建匹配卡片
    const matchCards = [];
    
    // 添加成语卡片
    selectedIdioms.forEach(idiom => {
        matchCards.push({
            type: 'idiom',
            content: idiom.idiom,
            pinyin: idiom.pinyin,
            matchId: idiom.id
        });
    });
    
    // 添加英文释义卡片
    selectedIdioms.forEach(idiom => {
        matchCards.push({
            type: 'meaning',
            content: idiom.english,
            matchId: idiom.id
        });
    });
    
    // 随机排序卡片
    shuffleArray(matchCards);
    
    // 添加卡片到容器
    matchCards.forEach(card => {
        const cardElement = document.createElement('div');
        cardElement.className = 'match-card';
        cardElement.setAttribute('data-type', card.type);
        cardElement.setAttribute('data-match-id', card.matchId);
        
        if (card.type === 'idiom') {
            cardElement.innerHTML = `
                <div class="match-idiom">${card.content}</div>
                <div class="match-pinyin">${card.pinyin}</div>
            `;
        } else {
            cardElement.innerHTML = `
                <div class="match-meaning">${card.content}</div>
            `;
        }
        
        cardElement.addEventListener('click', () => selectMatchCard(cardElement));
        matchContainer.appendChild(cardElement);
    });
}

// 选择匹配卡片
function selectMatchCard(card) {
    // 如果卡片已经匹配或已经选中，则忽略
    if (card.classList.contains('matched') || card.classList.contains('selected')) {
        return;
    }
    
    playSound('click');
    
    // 添加选中样式
    card.classList.add('selected');
    selectedMatchCards.push(card);
    
    // 如果选中了两张卡片，检查是否匹配
    if (selectedMatchCards.length === 2) {
        const card1 = selectedMatchCards[0];
        const card2 = selectedMatchCards[1];
        
        // 检查是否匹配（一张是成语，一张是释义，且匹配ID相同）
        if (
            card1.getAttribute('data-type') !== card2.getAttribute('data-type') &&
            card1.getAttribute('data-match-id') === card2.getAttribute('data-match-id')
        ) {
            // 匹配成功
            card1.classList.add('matched');
            card2.classList.add('matched');
            matchedPairs++;
            playSound('match');
            
            // 检查是否所有对都匹配完成
            if (matchedPairs === 4) {
                setTimeout(() => {
                    const completionMessage = document.createElement('div');
                    completionMessage.className = 'completion-message';
                    completionMessage.innerHTML = `
                        <div class="trophy"><i class="fas fa-trophy"></i></div>
                        <h3>恭喜！你完成了所有匹配！</h3>
                        <p>太棒了！你已经成功匹配了所有成语和它们的释义。</p>
                    `;
                    matchContainer.parentNode.insertBefore(completionMessage, matchContainer);
                    playSound('complete');
                }, 500);
            }
        } else {
            // 匹配失败，取消选中状态
            setTimeout(() => {
                card1.classList.remove('selected');
                card2.classList.remove('selected');
            }, 1000);
        }
        
        // 清空选中卡片数组
        setTimeout(() => {
            selectedMatchCards = [];
        }, 1000);
    }
}

// 更新进度条
function updateProgress() {
    let progress = 0;
    
    if (currentGame === 'learn') {
        progress = currentIdioms.length > 0 ? (currentIdiomIndex / (currentIdioms.length - 1)) * 100 : 0;
    } else if (currentGame === 'quiz') {
        progress = (quizScore.total > 0) ? (quizScore.correct / quizScore.total) * 100 : 0;
    } else if (currentGame === 'match') {
        progress = (matchedPairs / 4) * 100;
    }
    
    progressBar.style.width = `${progress}%`;
}

// 更新分数显示
function updateScoreDisplay() {
    scoreDisplay.textContent = `正确: ${quizScore.correct}/${quizScore.total}`;
    updateProgress();
}

// 辅助函数：随机打乱数组
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// 初始化应用
document.addEventListener('DOMContentLoaded', initApp);