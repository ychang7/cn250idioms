// 创建complete.mp3的替代方案
function generateCompleteSound() {
    if (!soundEnabled) return;
    
    try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        // 胜利音阶
        const frequencies = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
        const times = [0, 0.1, 0.2, 0.3];
        
        oscillator.frequency.setValueAtTime(frequencies[0], audioContext.currentTime + times[0]);
        oscillator.frequency.setValueAtTime(frequencies[1], audioContext.currentTime + times[1]);
        oscillator.frequency.setValueAtTime(frequencies[2], audioContext.currentTime + times[2]);
        oscillator.frequency.setValueAtTime(frequencies[3], audioContext.currentTime + times[3]);
        
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.5);
    } catch (e) {
        console.log('Web Audio API not supported');
    }
}